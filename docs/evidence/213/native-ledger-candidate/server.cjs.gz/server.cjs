"use strict";
// HTTP fixture only. Native browser interaction stays in the existing IAB tab.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),vm=require('node:vm'),{execFileSync}=require('node:child_process');
const {materialise}=require('../../tests/support/builds.js'),{startFake}=require('../../tests/support/cube-fake.js');
const hash=x=>crypto.createHash('sha256').update(x).digest('hex');
const ref=process.argv[2],port=Number(process.argv[3]||8795),out=__dirname,attribution=process.argv.includes('--attribute-ledger');
const harness=fs.readFileSync('tools/benchmark_continuations.mjs','utf8');
const profileSource=harness.slice(harness.indexOf('function appProfile(){'),harness.indexOf('\nconst profile=appProfile()'));
if(!profileSource.startsWith('function appProfile(){')||!profileSource.endsWith('}'))throw Error('Frozen profile function boundary changed');
const profile=vm.runInNewContext('('+profileSource+')()');
const build=materialise(ref,attribution?'native-continuations-attribution':'native-continuations-cap');let html=fs.readFileSync(path.join(build.dir,'index.html'),'utf8');
if(attribution){
  const before='        const failures = Object.fromEntries(window.explorerEvidence.REASONS.map';
  if(html.split(before).length!==2)throw Error('Ledger attribution boundary changed');
  html=html.replace(before,'        const endLedgerCount = diagnosticPhase("continuations.ledger-counts", { id });\n'+before);
  const after='        const summary = document.createElement("pre"); summary.textContent = JSON.stringify(counts, null, 2); host.append(summary);';
  if(html.split(after).length!==2)throw Error('Ledger count end changed');html=html.replace(after,'        endLedgerCount?.();\n'+after);
}
for(const [name,value]of [['explorer-commit',build.sha],['explorer-committed-at',execFileSync('git',['show','-s','--format=%cI',build.sha],{encoding:'utf8'}).trim()],['explorer-pr','https://github.com/Vaquum/Market-State-Cube-Explorer/pull/253']]){
  const before='<meta name="'+name+'" content="">';if(html.split(before).length!==2)throw Error('Missing metadata '+name);html=html.replace(before,'<meta name="'+name+'" content="'+value+'">');
}
fs.writeFileSync(path.join(build.dir,'index.html'),html);
(async()=>{const fake=await startFake({profile,pageRoot:build.dir,port,quiet:3600,next:3600,control:true});
  const identity={...build,stampedIndexSha256:hash(html),profileSourceSha256:hash(profileSource),profileSource,fixtureTradeCount:profile.trades.length,url:fake.url,adaptations:attribution?['Two optional recorder calls bracket the existing ledger count filters; attribution only, not exact committed HTML or an acceptance latency sample']:[],scope:'Committed-source full app, frozen synthetic 100k-column profile; adaptations explicitly identified; HTTP server only, no local browser launch'};
  fs.writeFileSync(path.join(out,'build-'+build.sha.slice(0,7)+(attribution?'-attribution':'')+'.json'),JSON.stringify(identity,null,2)+'\n');
  console.log(JSON.stringify(identity));
  process.on('SIGINT',async()=>{fs.writeFileSync(path.join(out,'server-log-'+build.sha.slice(0,7)+(attribution?'-attribution':'')+'.json'),JSON.stringify(fake.log(),null,2)+'\n');await fake.close();process.exit(0);});
})().catch(error=>{console.error(error);process.exitCode=1;});
